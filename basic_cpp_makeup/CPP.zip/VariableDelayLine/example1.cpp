#include <iostream>
#include "VDL_INQNET.h"

int main(){


  return 0;
}
