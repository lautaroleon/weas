#include "VDL_INQNET.h"


VDL::VDL(){

}

void VDL::fo(){


}

VDL::~VDL(){



}





