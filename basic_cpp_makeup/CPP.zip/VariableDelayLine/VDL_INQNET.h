#ifndef VDL_INQNET_H
#define VDL_INQNET_H 

#include <stdio.h>

	using namespace std;


class VDL
{  

public:

	void fo();



	VDL();
	~VDL();	


};

#endif 
